// Get tasks from localStorage or empty array
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

// Function to display tasks
function showTasks() {
  let list = document.getElementById("taskList");
  list.innerHTML = "";
  
  tasks.forEach((taskObj, index) => {
    let li = document.createElement("li");
    
    // Task text
    let span = document.createElement("span");
    span.innerText = taskObj.text;
    
    // Completed style
    if (taskObj.completed) {
      span.style.textDecoration = "line-through";
    }
    
    // Toggle complete
    span.onclick = function() {
      tasks[index].completed = !tasks[index].completed;
      localStorage.setItem("tasks", JSON.stringify(tasks));
      showTasks();
    };
    
    // Delete button
    let delBtn = document.createElement("button");
    delBtn.innerText = "❌";
    delBtn.style.marginLeft = "10px";
    
    delBtn.onclick = function() {
      tasks.splice(index, 1);
      localStorage.setItem("tasks", JSON.stringify(tasks));
      showTasks();
    };
    
    li.appendChild(span);
    li.appendChild(delBtn);
    list.appendChild(li);
  });
}

// Function to add task
function addTask() {
  let input = document.getElementById("taskInput");
  let taskText = input.value.trim();
  
  if (taskText === "") {
    alert("Please enter a task");
    return;
  }
  
  let newTask = {
    text: taskText,
    completed: false
  };
  
  tasks.push(newTask);
  
  localStorage.setItem("tasks", JSON.stringify(tasks));
  
  input.value = "";
  showTasks();
}

// Load tasks on page start
showTasks();